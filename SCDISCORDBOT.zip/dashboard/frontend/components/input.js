const input = {

};
window.input = input;