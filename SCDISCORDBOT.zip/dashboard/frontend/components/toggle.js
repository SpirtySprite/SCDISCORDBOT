const toggle = {

};
window.toggle = toggle;