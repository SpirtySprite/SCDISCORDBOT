A faire :

Changer tout ce qui est dans le .env (Du moins ce qui as besoin d'être modifier)

Lire le fichier DiscordConfig.yml pour comprendre comment fonctionne le bot
